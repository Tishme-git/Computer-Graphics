# Assignment on OpenGL

There are three tasks in this assignment.
1. Fully Controllable Camera (Problem 1.exe)
2. Gun (Problem 1.exe)
3. Bubbles (Problem 2.exe)

Full description about the tasks are in [Problem Description](https://github.com/Shukti042/Computer-Graphics/blob/master/OpenGL/Problem%20Description.pdf) file and the solutions are in [Problem 1](https://github.com/Shukti042/Computer-Graphics/tree/master/OpenGL/Problem%201) and [Problem 2](https://github.com/Shukti042/Computer-Graphics/tree/master/OpenGL/Problem%202). The outputs are in [Outputs](https://github.com/Shukti042/Computer-Graphics/tree/master/OpenGL/Outputs).