# Raster Based Graphics Pipeline

Full description about the tasks are in [Problem Description](https://github.com/Shukti042/Computer-Graphics/blob/master/Ray%20Tracing/Problem%20Specifications.pdf) file and the solutions are in [Solution](https://github.com/Shukti042/Computer-Graphics/tree/master/Ray%20Tracing/Solution).